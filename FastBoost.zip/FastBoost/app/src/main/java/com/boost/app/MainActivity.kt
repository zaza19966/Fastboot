package com.boost.app

import android.app.Activity
import android.app.ActivityManager
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var ramText: TextView
    private lateinit var ramBar: ProgressBar
    private lateinit var storageText: TextView
    private lateinit var storageBar: ProgressBar
    private lateinit var resultText: TextView
    private lateinit var boostBtn: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ramText = findViewById(R.id.ramText)
        ramBar = findViewById(R.id.ramBar)
        storageText = findViewById(R.id.storageText)
        storageBar = findViewById(R.id.storageBar)
        resultText = findViewById(R.id.resultText)
        boostBtn = findViewById(R.id.boostBtn)

        boostBtn.setOnClickListener { boost() }
        findViewById<View>(R.id.storageBtn).setOnClickListener {
            open(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)
        }
        findViewById<View>(R.id.devBtn).setOnClickListener {
            open(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)
        }
    }

    override fun onResume() {
        super.onResume()
        updateStats()
    }

    private fun memInfo(): ActivityManager.MemoryInfo {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        return ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
    }

    private fun colorFor(pct: Int): Int = when {
        pct >= 85 -> Color.parseColor("#F87171")
        pct >= 70 -> Color.parseColor("#FBBF24")
        else -> Color.parseColor("#22D3EE")
    }

    private fun setBar(bar: ProgressBar, pct: Int) {
        bar.progress = pct
        bar.progressTintList = ColorStateList.valueOf(colorFor(pct))
    }

    private fun updateStats() {
        // RAM
        val m = memInfo()
        val totalMb = m.totalMem / 1048576
        val freeMb = m.availMem / 1048576
        val ramPct = (100 - (freeMb * 100 / totalMb)).toInt()
        ramText.text = "المتاح $freeMb MB من $totalMb MB  •  المستخدم $ramPct%"
        setBar(ramBar, ramPct)

        // Storage
        val st = StatFs(Environment.getDataDirectory().path)
        val total = st.blockCountLong * st.blockSizeLong
        val free = st.availableBlocksLong * st.blockSizeLong
        val gb = 1073741824.0
        val stPct = (100 - (free * 100 / total)).toInt()
        storageText.text = String.format(
            Locale.US, "المتاح %.1f GB من %.1f GB  •  المستخدم %d%%",
            free / gb, total / gb, stPct
        )
        setBar(storageBar, stPct)
    }

    private fun boost() {
        boostBtn.isEnabled = false
        boostBtn.alpha = 0.6f
        resultText.text = "جارٍ التسريع..."
        Thread {
            val before = memInfo().availMem / 1048576
            val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager

            // إغلاق عمليات الخلفية للتطبيقات المثبتة من المستخدم
            for (app in packageManager.getInstalledApplications(0)) {
                if (app.packageName == packageName) continue
                if (app.flags and ApplicationInfo.FLAG_SYSTEM != 0) continue
                try { am.killBackgroundProcesses(app.packageName) } catch (_: Exception) {}
            }

            // تنظيف كاش التطبيق نفسه
            try {
                cacheDir.deleteRecursively()
                externalCacheDir?.deleteRecursively()
            } catch (_: Exception) {}

            Thread.sleep(1500)
            val after = memInfo().availMem / 1048576
            val freed = after - before

            runOnUiThread {
                updateStats()
                resultText.text = if (freed > 0) "تم تحرير حوالي $freed MB من الرام ✔"
                else "الجهاز نظيف بالفعل ✔"
                boostBtn.isEnabled = true
                boostBtn.alpha = 1f
            }
        }.start()
    }

    private fun open(action: String) {
        try {
            startActivity(Intent(action))
        } catch (e: Exception) {
            Toast.makeText(this, "غير متاح على هذا الجهاز", Toast.LENGTH_LONG).show()
        }
    }
}
